import { Component, OnInit } from '@angular/core';
import { FeeService } from '../../services/fee.service';

@Component({
  selector: 'app-month-summary',
  templateUrl: './month-summary.component.html',
  styleUrls: ['./month-summary.component.css']
})
export class MonthSummaryComponent implements OnInit {
  summary: { month: string; total: number; paid: number; unpaid: number }[] = [];

  constructor(private feeService: FeeService) {}

  ngOnInit(): void {
    this.feeService.all().subscribe(() => {
      this.summary = this.feeService.monthsWithTotals();
    });
  }
}