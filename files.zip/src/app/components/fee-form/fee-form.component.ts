import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FeeService } from '../../services/fee.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Fee } from '../../models/fee.model';

@Component({
  selector: 'app-fee-form',
  templateUrl: './fee-form.component.html',
  styleUrls: ['./fee-form.component.css']
})
export class FeeFormComponent implements OnInit {
  isEdit = false;
  id?: string;

  form = this.fb.group({
    description: ['', Validators.required],
    category: [''],
    amount: [0, [Validators.required, Validators.min(0.01)]],
    date: [new Date().toISOString().slice(0,10), Validators.required],
    paid: [false]
  });

  constructor(
    private fb: FormBuilder,
    private feeService: FeeService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.isEdit = true;
        this.id = params['id'];
        const fee = this.feeService.get(this.id!);
        if (fee) {
          this.form.patchValue({
            description: fee.description,
            category: fee.category,
            amount: fee.amount,
            date: fee.date.slice(0,10),
            paid: fee.paid
          });
        }
      }
    });
  }

  save() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const payload = {
      description: this.form.value.description!,
      category: this.form.value.category,
      amount: +this.form.value.amount!,
      date: new Date(this.form.value.date!).toISOString(),
      paid: !!this.form.value.paid
    };
    if (this.isEdit && this.id) {
      this.feeService.update(this.id, payload);
    } else {
      this.feeService.create(payload);
    }
    this.router.navigate(['/']);
  }

  cancel() {
    this.router.navigate(['/']);
  }
}