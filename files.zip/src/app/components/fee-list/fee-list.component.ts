import { Component, OnInit } from '@angular/core';
import { FeeService } from '../../services/fee.service';
import { Fee } from '../../models/fee.model';
import { Observable, map } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fee-list',
  templateUrl: './fee-list.component.html',
  styleUrls: ['./fee-list.component.css']
})
export class FeeListComponent implements OnInit {
  fees$: Observable<Fee[]>;
  monthFilter = this.currentMonth();

  constructor(private feeService: FeeService, private router: Router) {
    this.fees$ = this.feeService.all();
  }

  ngOnInit(): void {}

  currentMonth(): string {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }

  filteredFees(fees: Fee[]): Fee[] {
    if (!this.monthFilter) return fees;
    return fees.filter(f => f.date.slice(0, 7) === this.monthFilter);
  }

  edit(id: string) {
    this.router.navigate(['/edit', id]);
  }

  add() {
    this.router.navigate(['/add']);
  }

  delete(id: string) {
    if (!confirm('Delete this fee?')) return;
    this.feeService.delete(id);
  }

  togglePaid(id: string) {
    this.feeService.togglePaid(id);
  }

  totalForDisplayed(fees: Fee[]): number {
    return this.filteredFees(fees).reduce((s, f) => s + f.amount, 0);
  }
}