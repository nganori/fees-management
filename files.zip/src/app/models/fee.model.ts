export interface Fee {
  id: string;
  description: string;
  amount: number;
  date: string; // ISO date string (use to derive month)
  paid: boolean;
  category?: string;
}