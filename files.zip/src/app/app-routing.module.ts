import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeeListComponent } from './components/fee-list/fee-list.component';
import { FeeFormComponent } from './components/fee-form/fee-form.component';
import { MonthSummaryComponent } from './components/month-summary/month-summary.component';

const routes: Routes = [
  { path: '', component: FeeListComponent },
  { path: 'add', component: FeeFormComponent },
  { path: 'edit/:id', component: FeeFormComponent },
  { path: 'summary', component: MonthSummaryComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}