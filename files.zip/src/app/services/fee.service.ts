import { Injectable } from '@angular/core';
import { Fee } from '../models/fee.model';
import { BehaviorSubject, Observable } from 'rxjs';

const STORAGE_KEY = 'fees_manager_data';

@Injectable({
  providedIn: 'root'
})
export class FeeService {
  private fees$: BehaviorSubject<Fee[]> = new BehaviorSubject<Fee[]>(this.load());

  constructor() {}

  private load(): Fee[] {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // sample initial data
      const sample: Fee[] = [
        { id: this.uid(), description: 'Gym membership', amount: 50, date: new Date().toISOString(), paid: false, category: 'Health' },
        { id: this.uid(), description: 'Internet', amount: 30, date: new Date().toISOString(), paid: true, category: 'Utilities' }
      ];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(sample));
      return sample;
    }
    try {
      return JSON.parse(raw) as Fee[];
    } catch {
      return [];
    }
  }

  private save(fees: Fee[]) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fees));
    this.fees$.next(fees);
  }

  private uid(): string {
    return Math.random().toString(36).slice(2, 10);
  }

  all(): Observable<Fee[]> {
    return this.fees$.asObservable();
  }

  get(id: string): Fee | undefined {
    return this.fees$.value.find(f => f.id === id);
  }

  create(fee: Omit<Fee, 'id'>) {
    const newFee: Fee = { ...fee, id: this.uid() };
    const next = [...this.fees$.value, newFee];
    this.save(next);
    return newFee;
  }

  update(id: string, patch: Partial<Fee>) {
    const next = this.fees$.value.map(f => f.id === id ? { ...f, ...patch } : f);
    this.save(next);
  }

  delete(id: string) {
    const next = this.fees$.value.filter(f => f.id !== id);
    this.save(next);
  }

  togglePaid(id: string) {
    const fee = this.get(id);
    if (!fee) return;
    this.update(id, { paid: !fee.paid });
  }

  feesByMonth(monthIso: string): Fee[] {
    // monthIso: 'YYYY-MM' format
    return this.fees$.value.filter(f => f.date.slice(0, 7) === monthIso);
  }

  monthsWithTotals(): { month: string; total: number; paid: number; unpaid: number }[] {
    const map = new Map<string, { total: number; paid: number; unpaid: number }>();
    for (const f of this.fees$.value) {
      const m = f.date.slice(0, 7);
      const existing = map.get(m) ?? { total: 0, paid: 0, unpaid: 0 };
      existing.total += f.amount;
      if (f.paid) existing.paid += f.amount; else existing.unpaid += f.amount;
      map.set(m, existing);
    }
    const arr = Array.from(map.entries()).map(([month, totals]) => ({ month, ...totals }));
    // sort descending
    arr.sort((a, b) => b.month.localeCompare(a.month));
    return arr;
  }
}