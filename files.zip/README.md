```markdown
# Fees Manager (Angular)

Simple Angular app to manage fees per month.

Features
- Add/edit/delete fees
- Mark fees as paid/unpaid
- Filter fees by month
- Monthly summary (total, paid/unpaid)

How to run
1. Ensure Node.js and Angular CLI are installed.
2. Create a new project:
   - ng new fees-manager --routing=false --style=css
   - cd fees-manager
3. Copy the files from this repository into `src/app` and update `src/main.ts`/`index.html` if you replaced them.
4. Install dependencies (if you changed package.json):
   - npm install
5. Serve:
   - ng serve
6. Open http://localhost:4200

Notes
- Data is stored in localStorage under key `fees_manager_data`.
- You can add enhancements: sorting, CSV export, backend API.
```